module.exports = () => {
    const data = { restaurent: [] }
    // Create 1000 users
    for (let i = 0; i < 1000; i++) {
      data.users.push({ id: i, name: `restaurent${i}` })
    }
    return data
  }