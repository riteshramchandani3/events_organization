import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
import Home from './components/Home'
import RestaurantsList from './components/RestaurantsList'
import RestaurantsCreate from './components/RestaurentCreate'
import RestaurentDetails from './components/RestaurentDetails'
import RestaurentSearch from './components/RestaurentSearch'
import RestaurentUpdate from './components/RestaurentUpdate'
import { Navbar } from 'react-bootstrap';
import { Nav } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import hungry from '../src/hungry.png'
import {  faTrash, faList,  faHome, faPlus, faSearch } from '@fortawesome/free-solid-svg-icons'
function App() {
  return (
    <div>
      <Router>
        <Navbar bg="light" expand="lg">

     
          <Navbar.Brand> <img src={hungry}/>&nbsp;<b>Foody Buddy</b></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto pull-left">
              <Nav.Link href="#home"><Link to="/"><FontAwesomeIcon icon={faHome} /></Link></Nav.Link>
              <Nav.Link href="#link"><Link to="/list"><FontAwesomeIcon icon={faList} /></Link></Nav.Link>
              <Nav.Link href="#link"><Link to="/create"><FontAwesomeIcon icon={faPlus} /></Link></Nav.Link>
              <Nav.Link href="#link"><Link to="/search"><FontAwesomeIcon icon={faSearch} /></Link></Nav.Link>

            </Nav>

          </Navbar.Collapse>
        </Navbar>




        <Route path="/list">
          <RestaurantsList />

        </Route>
        <Route path="/create">
          <RestaurantsCreate />
        </Route>
        <Route path="/detail">
          <RestaurentDetails />
        </Route>
        <Route path="/search">
          <RestaurentSearch />
        </Route>
        <Route path="/update/:id"
          render={props => (
            <RestaurentUpdate {...props} />
          )}
        >

        </Route>
      </Router>
    </div>
  );
}

export default App;
