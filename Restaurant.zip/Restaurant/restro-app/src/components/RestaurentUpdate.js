import React, { Component } from 'react'
import { Col } from 'react-bootstrap'
import { Row } from 'react-bootstrap'
import { Button } from 'react-bootstrap'
import {withRouter} from 'react-router-dom';



 class RestaurentUpdate extends Component {

  constructor() {
    super();
    this.state = {
      name: null,
      address: null,
      rating: null,
      email: null,
      id: null

    }

  }



  componentDidMount() {
    fetch('http://localhost:3000/restaurent/' + this.props.match.params.id).then((response) => {
      response.json().then((result) => {
        console.warn(result)
        this.setState({
          name: result.name,
          id: result.id,
          address: result.address,
          rating: result.rating,
          email: result.email
        })

      })

    })
  }

  update() {

    fetch('http://localhost:3000/restaurent/' + this.state.id, {

      method: "PUT",
      headers: {
        'Content-Type': 'application/json '
      },
      body: JSON.stringify(this.state)
    }
    ).then((response) => {
      response.json().then((result) => {

      })
      this.props.history.push('/list');


    })
  }
  render() {

    //console.warn(this.props.match.params.id)
    //console.warn(this.props.match.params.id)
    return (
      <div className="container">
        <center><h1>Update Restaurent</h1></center><br />

        <Row>
          <Col xs={2}><label>Restaurent Name</label></Col>

          <Col xs={4}><input type="text" name="name" className="form-control" onChange={(event) => { this.setState({ name: event.target.value }) }} value={this.state.name} /><br /></Col>
        </Row>
        <Row>
          <Col xs={2}><label>Restaurent Address</label></Col>

          <Col xs={4}><input type="text" name="address" className="form-control" onChange={(event) => { this.setState({ address: event.target.value }) }} value={this.state.address} /><br /></Col>
        </Row>
        <Row>
          <Col xs={2}><label>Restaurent Rating</label></Col>

          <Col xs={4}><input type="text" name="rating" className="form-control" onChange={(event) => { this.setState({ rating: event.target.value }) }} value={this.state.rating} /><br /></Col>
        </Row>
        <Row>
          <Col xs={2}><label>Restaurent Email</label></Col>

          <Col xs={4} ><input type="text" name="email" className="form-control" onChange={(event) => { this.setState({ email: event.target.value }) }} value={this.state.email} /><br /></Col>
        </Row>

        <Button onClick={() => this.update()}>Update</Button>




      </div>
    )
  }
}
export default withRouter(RestaurentUpdate);
