import React, { Component } from 'react'
import { Row } from 'react-bootstrap'
import { Col } from 'react-bootstrap'
import { Button } from 'react-bootstrap'
import { withRouter } from 'react-router-dom';



class RestaurentCreate extends Component {

    constructor() {
        super();
       this.state = {
            name: null,
            address: null,
            rating: null,
            email: null

        }


    }
    
    create() {

        
        fetch('http://localhost:3000/restaurent', {

            method: "post",
            headers: {
                'Content-Type': 'application/json '
            },
            body: JSON.stringify(this.state)
        }
        ).then((response) => {
            response.json().then((result) => {

            })

            this.props.history.push('/list');


        })


    }

    

    render() {
        return (
            <div className="container">
                <center><h1>Create A New Restaurent</h1></center><br />
                <form autoComplete="off">
                <Row>
                    <Col xs={2}><label>Restaurent Name</label></Col>

                    <Col xs={4}><input type="text" name="name" className="form-control" onChange={(event) => { this.setState({ name: event.target.value }) }} /><br /></Col>
                </Row>
                <Row>
                    <Col xs={2}><label>Communication Address</label></Col>

                    <Col xs={4}><input type="text" name="address" className="form-control" onChange={(event) => { this.setState({ address: event.target.value }) }} /><br /></Col>
                </Row>
                <Row>
                    <Col xs={2}><label>Restaurent Rating</label></Col>

                    <Col xs={4}><input type="text" name="rating" className="form-control" onChange={(event) => { this.setState({ rating: event.target.value }) }} /><br /></Col>
                </Row>
                <Row>
                    <Col xs={2}><label>Restaurent Email</label></Col>

                    <Col xs={4} ><input type="text" name="email" className="form-control" onChange={(event) => { this.setState({ email: event.target.value }) }} /><br /></Col>
                </Row>

                <Button onClick={() => this.create()}>Submit</Button>

                </form>


            </div>
        )
    }
}
export default withRouter(RestaurentCreate);
