import React, { Component } from 'react'
import { Table } from 'react-bootstrap'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCoffee, faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons'


export default class RestaurantsList extends Component {

    constructor() {
        super();
        this.state = {
            list: null,
        }
    }y


    delete(id) {
        fetch('http://localhost:3000/restaurent/' + id,

            {

                method: "DELETE",


            }).then((response) => {
                response.json().then((result) => {

                    this.getList()


                })

            })


    }

    // componentDidMount() {
    //     fetch("http://localhost:3000/restaurent").then((response) => {
    //         response.json().then((result) => {
    //             this.setState({
    //                 list: result
    //             })

    //         })

    //     })
    // }

    componentDidMount() {

        this.getList()
    }


    getList() {
        fetch("http://localhost:3000/restaurent").then((response) => {
            response.json().then((result) => {
                this.setState({
                    list: result
                })

            })

        })

    }
    render() {
        return (
            <div className="container">
                <h1><center>Restaurent List</center></h1>

                {

                    this.state.list ?
                        <div>

                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Communication Address</th>
                                        <th>Email</th>
                                        <th>Rating</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    {
                                        this.state.list.map((item, i) =>
                                            <tr>
                                                <td>{item.id}</td>
                                                <td>{item.name}</td>
                                                <td>{item.address}</td>
                                                <td>{item.email}</td>
                                                <td>{item.rating}</td>
                                                <td>
                                                    <Link to={"/update/" + item.id}><FontAwesomeIcon icon={faEdit} color={'green'} /></Link>&nbsp;
                                                <span onClick={() => this.delete(item.id)}><FontAwesomeIcon icon={faTrashAlt} color={'#C50707'} /></span>

                                                </td>
                                            </tr>






                                        )

                                    }
                                </tbody>
                            </Table>
                        </div>
                        :
                        <p>please wait</p>
                }
            </div>
        )
    }
}
