import React, { Component } from 'react'
import { InputGroup } from 'react-bootstrap'
import {Table} from 'react-bootstrap'

export default class RestaurentSearch extends Component {


  constructor() {

    super();
    this.state = {

      searchData: null,
      noData: false
    }
  }

  search(key) {

    console.warn(key)
    fetch("http://localhost:3000/restaurent?q=" + key).then((data) => {

      data.json().then((resp) => {


        if (resp.length > 0) {
          this.setState({ searchData: resp, noData: false })

        }
        else {

          this.setState({ noData: true, search: null })
        }


      })
    })

  }
  render() {
    return (
      <div>
        <center><h1>Search Restaurent</h1></center>

        <input type="text" name="search" onChange={(event) => this.search(event.target.value)} placeholder="Search" /><br/> <br/>  


        <div>{
          this.state.searchData ?

            <div>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Rating</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    this.state.searchData.map((item) =>
                    <tr>
                     
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>{item.address}</td>
                        <td>{item.email}</td>
                        <td>{item.rating}</td>
                     </tr>
                     
                      )
                     
                  }
                </tbody>
              </Table>
            </div> : ""
        }
          {
            this.state.noData ? <h1>No data Found</h1> : null
          }

        </div>


      </div>

    )
  }
}
